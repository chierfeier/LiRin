
# [expr  for  val  in   collection]

a = [i**2 for i in range(1,6) ]
print(a)

b = [4*i for i in a]
print(b)


# b = [4*k for k in a]
# print(b)
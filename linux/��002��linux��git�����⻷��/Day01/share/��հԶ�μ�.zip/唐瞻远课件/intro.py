[expr  for  val  in   collection]

[expr  for  val  in   collection  if  <criteria>]

[expr  for  val  in   collection  if  <criteria1>]

[expr  for  val1  in   collection  and  val2  in collection2   ]